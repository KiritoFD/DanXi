import { Project } from '@ohos/hvigor';

export default {
  project: {
    name: 'danxi',
    version: '1.4.5',
    type: 'app',
  },
  targets: {
    default: {
      compiler: {
        options: {
          sourceMap: true,
          optimizeLevel: 'O0',
        },
      },
    },
  },
} as Project;
